<?php

namespace Terrificminds\CustomRequestForm\Api;

use Magento\Framework\Api\SearchCriteriaInterface;
use Terrificminds\CustomRequestForm\Api\Data\CustomInterface;

interface CustomRepositoryInterface
{
    /**
     * To get id
     *
     * @param int $id
     * @return \Terrificminds\CustomRequestForm\Data\CustomInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getById($id);

    /**
     * To save
     *
     * @param Terrificminds\CustomRequestForm\Api\Data\CustomInterface $custom
     * @return \Terrificminds\CustomRequestForm\Api\Data\CustomInterface
     */
    public function save(CustomInterface $custom);

    /**
     * To delete
     *
     * @param \Terrificminds\CustomRequestForm\Api\Data\CustomInterface $custom
     * @return void
     */
    public function delete(CustomInterface $custom);

    /**
     * To get list
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Terrificminds\CustomRequestForm\Api\Data\CustomSearchResultInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}
