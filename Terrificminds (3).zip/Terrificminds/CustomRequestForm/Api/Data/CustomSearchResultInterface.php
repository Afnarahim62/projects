<?php

namespace Terrificminds\CustomRequestForm\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

interface CustomSearchResultInterface extends SearchResultsInterface
{
    /**
     * GetItem function
     *
     * @return \Terrificminds\CustomRequestForm\Api\Data\CustomInterface[]
     */
    public function getItems();

    /**
     * SetItem function
     *
     * @param \Terrificminds\CustomRequestForm\Api\Data\CustomInterface[] $items
     * @return void
     */
    public function setItems(array $items);
}
