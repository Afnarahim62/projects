<?php

/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Terrificminds\CustomRequestForm\Api\Data;

/**
 * @api
 * @since 100.0.2
 */
interface CustomInterface
{
    /**#@+
     * Constants defined for keys of  data array
     */
    public const ID = 'id';
    public const NAME = 'customer_name';
    public const EMAIL = 'email';
    public const CAPACITY = 'capacity';
    public const QUANTITY = 'qty';
    public const CUSTOMIZATION_REQUIREMENT = 'customization';
    public const DESCRIPTION = 'description';
    public const ATTRIBUTES = [
        self::ID,
        self::NAME,
        self::EMAIL,
        self::CAPACITY,
        self::QUANTITY,
        self::CUSTOMIZATION_REQUIREMENT,
        self::DESCRIPTION,
    ];
    /**
     *  Id
     *
     * @return int|null
     */
    public function getId();

    /**
     * Set  id
     *
     * @param int $id
     * @return $this
     */
    public function setId($id);
    /**
     * Customer name
     *
     * @return string|null
     */
    public function getName();

    /**
     * Set customer name
     *
     * @param string $name
     * @return $this
     */
    public function setName($name);
     /**
      * Customer email
      *
      * @return string|null
      */
    public function getEmail();

    /**
     * Set customer email
     *
     * @param string $email
     * @return $this
     */
    public function setEmail($email);
       /**
        *  Capacity
        *
        * @return  float|null
        */
    public function getCapacity();

    /**
     * Set  Capacity
     *
     * @param  float $capacity
     * @return $this
     */
    public function setCapacity($capacity);
  /**#@-*/

    /**
     * Product quantity
     *
     * @return int|null
     */
    public function getQuantity();

    /**
     * Set product quantity
     *
     * @param int $qty
     * @return $this
     */
    public function setQuantity($qty);

    /**
     * Customization Requirement
     *
     * @return string|null
     */
    public function getCustomization();

    /**
     * Set Customization Requirement
     *
     * @param string $customization
     * @return $this
     */
    public function setCustomization($customization);

    /**
     * Product description
     *
     * @return string|null
     */
    public function getDescription();

    /**
     * Set product description
     *
     * @param string $description
     * @return $this
     */
    public function setDescription($description);
}
