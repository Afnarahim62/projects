<?php

namespace Terrificminds\CustomRequestForm\Model;

use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\NoSuchEntityException;
use Terrificminds\CustomRequestForm\Api\Data\CustomInterface;
use Terrificminds\CustomRequestForm\Api\Data\CustomSearchResultInterfaceFactory;
use Terrificminds\CustomRequestForm\Api\CustomRepositoryInterface;
use Terrificminds\CustomRequestForm\Model\ResourceModel\CustomBottleRequest;
use Terrificminds\CustomRequestForm\Model\ResourceModel\CustomBottleRequest\CollectionFactory;

class CustomRepository implements CustomRepositoryInterface
{
    /**
     * @var CustomBottleRequestFactory
     */
    protected $CustomBottleRequestFactory;

    /**
     * @var customBottle
     */
    protected $CustomResource;

    /**
     * @var CustomBottleRequestCollectionFactory
     */
    protected $CustomBottleRequestCollectionFactory;

    /**
     * @var CustomSearchResultInterfaceFactory
     */
    protected $searchResultFactory;
    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     *
     * @param CustomBottleRequestFactory $CustomBottleRequestFactory
     * @param CustomBottleRequest $CustomResource
     * @param CollectionFactory $CustomBottleRequestCollectionFactory
     * @param CustomSearchResultInterfaceFactory $CustomSearchResultInterfaceFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        CustomBottleRequestFactory $CustomBottleRequestFactory,
        CustomBottleRequest $CustomResource,
        CollectionFactory $CustomBottleRequestCollectionFactory,
        CustomSearchResultInterfaceFactory $CustomSearchResultInterfaceFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->CustomBottleRequestFactory = $CustomBottleRequestFactory;
        $this->CustomResource = $CustomResource;
        $this->CustomBottleRequestCollectionFactory = $CustomBottleRequestCollectionFactory;
        $this->searchResultFactory = $CustomSearchResultInterfaceFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * To get by id
     *
     * @param int $id
     * @return \Terrificminds\CustomRequestForm\Api\Data\CustomInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getById($id)
    {
        $customBottle = $this->CustomBottleRequestFactory->create();
        $this->CustomResource->load($customBottle, $id);
        if (!$customBottle->getId()) {
            throw new NoSuchEntityException(__('Unable to find bottle with ID "%1"', $id));
        }
        return $customBottle;
    }

    /**
     * To Save
     *
     * @param \Terrificminds\CustomRequestForm\Api\Data\CustomInterface $customBottle
     * @return \Terrificminds\CustomRequestForm\Api\Data\CustomInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(CustomInterface $customBottle)
    {
        $this->CustomResource->save($customBottle);
        return $customBottle;
    }

    /**
     * To delete
     *
     * @param \Terrificminds\CustomRequestForm\Api\Data\CustomInterface $customBottle
     * @return bool true on success
     * @throws \Magento\Framework\Exception\CouldNotDeleteException
     */
    public function delete(CustomInterface $customBottle)
    {
        try {
            $this->CustomResource->delete($customBottle);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(
                __('Could not delete the entry: %1', $exception->getMessage())
            );
        }

        return true;
    }

    /**
     * To get the List
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Terrificminds\CustomRequestForm\Api\Data\CustomSearchResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        $collection = $this->CustomBottleRequestCollectionFactory->create();
        $this->collectionProcessor->process($searchCriteria, $collection);
        $searchResults = $this->searchResultFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);
        $searchResults->setItems($collection->getItems());
        return $searchResults;
    }
}
