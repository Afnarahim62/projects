<?php

namespace Terrificminds\CustomRequestForm\Model\ResourceModel\CustomBottleRequest;

use Terrificminds\CustomRequestForm\Model\CustomBottleRequest;
use Terrificminds\CustomRequestForm\Model\ResourceModel\CustomBottleRequest as CustomResourceModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * Construct function
     */
    protected function _construct()
    {
        $this->_init(
            CustomBottleRequest::class,
            CustomResourceModel::class
        );
    }
}
