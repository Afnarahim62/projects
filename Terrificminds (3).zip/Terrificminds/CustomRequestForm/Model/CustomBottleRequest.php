<?php

namespace  Terrificminds\CustomRequestForm\Model;

use Magento\Framework\Model\AbstractModel;
use Terrificminds\CustomRequestForm\Api\Data\CustomInterface;

class CustomBottleRequest extends AbstractModel implements CustomInterface
{
    /**
     * @var string
     */
    protected const CACHE_TAG = 'md_customer_bottle_request';
    /**
     * @var string
     */
    protected $_cacheTag = 'md_customer_bottle_request';
    /**
     * @inheritDoc
     */
    public function getId()
    {
        return parent::getData(self::ID);
    }

    /**
     * @inheritDoc
     */
    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return parent::getData(self::NAME);
    }

    /**
     * @inheritDoc
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }

    /**
     * @inheritDoc
     */
    public function getEmail()
    {
        return parent::getData(self::EMAIL);
    }

    /**
     * @inheritDoc
     */
    public function setEmail($email)
    {
        return $this->setData(self::EMAIL, $email);
    }
     /**
      * @inheritDoc
      */
    public function getCapacity()
    {
        return parent::getData(self::CAPACITY);
    }

    /**
     * @inheritDoc
     */
    public function setCapacity($capacity)
    {
        return $this->setData(self::CAPACITY, $capacity);
    }
     /**
      * @inheritDoc
      */
    public function getQuantity()
    {
        return parent::getData(self::QUANTITY);
    }

    /**
     * @inheritDoc
     */
    public function setQuantity($qty)
    {
        return $this->setData(self::QUANTITY, $qty);
    }
    /**
     * @inheritDoc
     */
    public function getCustomization()
    {
        return parent::getData(self::CUSTOMIZATION_REQUIREMENT);
    }

    /**
     * @inheritDoc
     */
    public function setCustomization($customization)
    {
        return $this->setData(self::CUSTOMIZATION_REQUIREMENT, $customization);
    }
    
    /**
     * GetDescription function
     *
     * @return string
     */
    public function getDescription()
    {
        return parent::getData(self::DESCRIPTION);
    }

    /**
     * SetDescription  function
     *
     * @param string $description
     * @return string
     */
    public function setDescription($description)
    {
        return $this->setData(self::DESCRIPTION, $description);
    }

    /**
     * Construct function
     */
    protected function _construct()
    {
        $this->_init(ResourceModel\CustomBottleRequest::class);
    }

    /**
     * GetIdentities function
     *
     * @return id
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * GetDefaultValues function
     *
     * @return array
     */
    public function getDefaultValues()
    {
        $values = [];
        return $values;
    }
}
