<?php

namespace Terrificminds\CustomRequestForm\Model;

use Magento\Framework\Api\SearchResults;
use Terrificminds\CustomRequestForm\Api\Data\CustomSearchResultInterface;

class CustomSearchResult extends SearchResults implements CustomSearchResultInterface
{
}
