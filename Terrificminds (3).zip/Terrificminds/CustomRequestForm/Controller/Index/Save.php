<?php

namespace Terrificminds\CustomRequestForm\Controller\Index;

use Terrificminds\CustomRequestForm\Api\CustomRepositoryInterface;
use Terrificminds\CustomRequestForm\Api\Data\CustomInterfaceFactory;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

class Save extends Action
{
    /**
     * @var CustomRepositoryInterface
     */
    protected $CustomRepository;
    /**
     * @var CustomInterfaceFactory
     */
    private $CustomFactory;
    /**
     * Construct function
     *
     * @param Context $context
     * @param CustomRepositoryInterface $CustomRepository
     * @param CustomInterfaceFactory $CustomFactory
     */
    public function __construct(
        Context  $context,
        CustomRepositoryInterface $CustomRepository,
        CustomInterfaceFactory $CustomFactory
    ) {
        $this->CustomRepository = $CustomRepository;
        $this->CustomFactory = $CustomFactory;
        parent::__construct($context);
    }
    /**
     * Execute function
     *
     * @return url
     */
    public function execute()
    {
        $params = $this->_request->getParams();
        $setProduct = $this->CustomFactory ->create();
        $setProduct->setName($params['name']);
        $setProduct->setEmail($params['email']);
        $setProduct->setCustomization($params['custom']);
        $setProduct->setCapacity($params['volume']);
        $setProduct->setQuantity($params['no_bottle']);
        $setProduct->setDescription($params['description']);
        try {
            $this->CustomRepository->save($setProduct);
            $this->messageManager->addSuccessMessage(__("Request is send"));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__("Something went wrong"));
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setUrl('https://app.exampleproject.test/CustomRequestForm/');
    }
}
