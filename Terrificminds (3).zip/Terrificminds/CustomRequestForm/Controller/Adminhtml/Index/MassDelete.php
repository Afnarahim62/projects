<?php

namespace Terrificminds\CustomRequestForm\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Terrificminds\CustomRequestForm\Model\CustomBottleRequestFactory;

/**
 * Class MassDelete
 * to delete in mass action
 */
class MassDelete extends \Magento\Backend\App\Action
{
    /**
     * Undocumented variable
     *
     * @var CustomBottleRequestFactory
     */
    private $_bottleRequestListFactory;

    /**
     * Constructor
     *
     * @param CustomBottleRequestFactory $_bottleRequestListFactory
     * @param Context $context
     */
    public function __construct(
        CustomBottleRequestFactory $_bottleRequestListFactory,
        Context $context
    ) {
        $this->_bottleRequestListFactory = $_bottleRequestListFactory;
        parent::__construct($context);
    }

    /**
     * Execute function
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        $selectedIds = $data['selected'];
        try {
            foreach ($selectedIds as $selectedId) {
                $deleteData = $this->_bottleRequestListFactory->create()->load($selectedId);
                $deleteData->delete();
            }
            $this->messageManager->addSuccessMessage(__('Row data has been successfully deleted.'));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__($e->getMessage()));
        }
        return $this->_redirect('customrequestform/index/index');
    }

    /**
     * IsAllowed function
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Terrificminds_CustomRequestForm::home');
    }
}
