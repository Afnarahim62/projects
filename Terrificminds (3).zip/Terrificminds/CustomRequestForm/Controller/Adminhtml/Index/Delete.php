<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 *
 * Created By : Rohan Hapani
 */

namespace Terrificminds\CustomRequestForm\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Terrificminds\CustomRequestForm\Model\CustomBottleRequest;

class Delete extends Action
{
    /**
     * @var \Terrificminds\CustomRequestForm\Model\CustomBottleRequest
     */
    protected $modelBlog;
    /**
     *
     * @param Context $context
     * @param \Terrificminds\CustomRequestForm\Model\CustomBottleRequest $blogFactory
     */
    public function __construct(
        Context $context,
        CustomBottleRequest $blogFactory
    ) {
        parent::__construct($context);
        $this->modelBlog = $blogFactory;
    }
    /**
     * Isallowed function
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Terrificminds_CustomRequestForm::index_delete');
    }
    /**
     * Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                $model = $this->modelBlog;
                $model->load($id);
                $model->delete();
                $this->messageManager->addSuccessMessage(__('Record deleted successfully.'));
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
            }
        }
        $this->messageManager->addErrorMessage(__('Record does not exist.'));
        return $resultRedirect->setPath('*/*/');
    }
}
