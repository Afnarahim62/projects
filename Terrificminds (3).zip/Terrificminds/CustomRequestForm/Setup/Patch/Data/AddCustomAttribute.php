<?php

namespace Terrificminds\CustomRequestForm\Setup\Patch\Data;

use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;

class AddCustomAttribute implements DataPatchInterface
{
    public const ATTRIBUTE_NAME = "bottle_volume";

     /**
      * @var EavSetupFactory
      */
    public $eavSetupFactory;

    /**
     * @var ModuleDataSetupInterface
     */

    private $moduleDataSetup;

    /**
     *
     * @param ModuleDataSetupInterface $moduleDataSetup
     * @param EavSetupFactory $eavSetupFactory
     */
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        EavSetupFactory $eavSetupFactory
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
        $this->eavSetupFactory = $eavSetupFactory;
    }

    /**
     * GetDependencies function
     *
     * @return array
     */
    public static function getDependencies()
    {
        return [];
    }

    /**
     * GetAliases function
     *
     * @return array
     */
    public function getAliases()
    {
        return [];
    }

    /**
     * Apply function
     *
     * @return object
     */
    public function apply()
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $this->moduleDataSetup]);
        $eavSetup->addAttribute(\Magento\Catalog\Model\Product::ENTITY, self::ATTRIBUTE_NAME, [
            'position' => 200,
            'type'  => 'decimal',
            'label' => 'Bottle Volume',
            'input' => 'multiselect',
            'user_defined' => false,
            'required' => true,
            'is_global' => true,
            'is_searchable' => true,
            'is_used_in_grid' => true,
            'is_visible_in_grid' => true,
            'visiblity' => 'true',
            'is_filterable_in_grid' => true,
            'search_weight' => 5,
            'source' => '',
            'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_STORE,
            'backend' => Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend::class,
            'option' => ['values' => [
                '0.6',
                '1.0',
                ],
            ],
        ]);
        return $this;
    }
}
