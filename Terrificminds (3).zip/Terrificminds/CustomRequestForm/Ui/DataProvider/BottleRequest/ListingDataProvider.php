<?php

namespace Terrificminds\CustomRequestForm\Ui\DataProvider\BottleRequest;

/**
 * Class ListingDataProvider to list data
 */
class ListingDataProvider extends \Magento\Framework\View\Element\UiComponent\DataProvider\DataProvider
{
}
