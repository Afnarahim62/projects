define([
    'ko',
    'uiComponent'
], function (ko, Component) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Terrificminds_CustomField/shipping/landmark'
        },
    //    getCategory () {
    //      let 
    //    } 
    // getStoreAttributeValue: function () {
    //     var getStore;
    //     $.ajax({
    //         url: urlBuilder.build('terrificminds/quote/getProductCategory'),
    //         type: 'POST',
    //         cache: false,
    //         async: false,
    //         success: function (response) {
    //             getStore = response.storeAttribute;
    //         }
    //     })
    //     return getStore;
    // },
    });


});